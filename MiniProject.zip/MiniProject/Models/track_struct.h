#ifndef TRACK_STRUCT
#define TRACK_STRUCT

struct Track {
    char name[20];
    int uid;
};

#endif