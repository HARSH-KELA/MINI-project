#ifndef ENROLL_STRUCT
#define ENROLL_STRUCT

struct Enroll {
    int sid;
    int active;
};

#endif