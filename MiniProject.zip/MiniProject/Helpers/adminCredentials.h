#ifndef ADMIN_CREDENTIALS
#define ADMIN_CREDENTIALS

#define SUPERID "admin"
#define SUPERPASSWORD "admin"

#endif